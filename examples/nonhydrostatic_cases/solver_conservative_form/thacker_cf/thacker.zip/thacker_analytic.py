# Analytic solution to Thacker wetting-drying test case

import numpy as np
from matplotlib import pyplot as plt
from matplotlib import rc

plt.rc('font', family='serif', size=24)


# Parameters ###########################
D0 = 50.0
L = 430620
eta0 = 2.0
A = ((D0+eta0)**2-D0**2)/((D0+eta0)**2+D0**2)
R = 430620.0
omega = (8*9.81*D0/(R**2))**0.5

xplot = np.linspace(-475823.23, 475823.23, 1000)

# Bathymetry and analytic solution #####
bathy = -D0*(1-(xplot**2)/(L**2))
def analytic(t):
    return D0*(((1-A**2)**0.5)/(1-A*np.cos(omega*t)) - 1 - (xplot**2)/(R**2)*((1-A**2)/((1-A*np.cos(omega*t))**2)-1))

# Plot solution ########################
fig = plt.figure(figsize=(10, 5))
ax = fig.add_subplot(111)

plt.plot(xplot/1000, bathy, 'k', linewidth=4)
plt.plot(xplot/1000, analytic(0), 'k', linewidth=2)
plt.plot(xplot/1000, analytic(6*3600), 'k', linewidth=2)

plt.xlim(-500, 500)
plt.ylim(-8, 4)
plt.xlabel('r / km')
plt.ylabel('elevation / m')
plt.tight_layout()
plt.show()
