# Thacker, for comparison with DG-SWEM
# ================================================================================
from thetis import *
import os.path
from math import pi

def run_thacker(od='outputs', mesh='meshes/04.msh', alpha=1.0, dt=60.):
#    output_dir = create_directory(od)
    mesh2d = Mesh(mesh)
    print('Loaded mesh '+mesh2d.name)
#    print('Exporting to '+output_dir)

    # Model setup
    D0 = Constant(50.)
    L = Constant(430620.)
    eta0 = Constant(2.)
    a = ((D0+eta0)**2-D0**2)/((D0+eta0)**2+D0**2)
    A = Constant(a)

    # Time steps, total simulation time
    t_export = dt
    t_end = 2*43200. - 0.1*dt

    # bathymetry
    P1 = FunctionSpace(mesh2d, "CG", 1)
    bathymetry = Function(P1, name='bathymetry')
    x = SpatialCoordinate(mesh2d)
    bathy = D0*(1-(x[0]*x[0]+x[1]*x[1])/(L*L))
    bathymetry.interpolate(bathy)

    print 'bath', bathymetry.dat.data.min(), bathymetry.dat.data.max()

    h_viscosity = None
    mu_manning = None
    wd_alpha = Constant(alpha)

    # --- create solver ---
    solverObj = solver2d.FlowSolver2d(mesh2d, bathymetry)
    options = solverObj.options
    options.no_exports = True
    options.element_family = 'dg-dg'
    options.cfl_2d = 1.0
    options.nonlin = True
    options.t_export = t_export
    options.t_end = t_end
#    options.outputdir = output_dir
    options.check_vol_conservation_2d = True
    options.fields_to_export = None#['uv_2d', 'elev_2d']
    options.timestepper_type = 'cranknicolson'
    options.shallow_water_theta = 0.5
    options.use_linearized_semi_implicit_2d = False
    options.wetting_and_drying = True
    options.wd_alpha = wd_alpha
    options.mu_manning = mu_manning
    options.h_viscosity = h_viscosity
    # only important if viscosity is included:
    options.include_grad_div_viscosity_term = False
    options.include_grad_depth_viscosity_term = False
    options.dt = dt
    options.solver_parameters_sw = {
        'snes_type': 'newtonls',
        'snes_monitor': False,
        'ksp_type': 'gmres',
        'pc_type': 'fieldsplit',
    }

    solverObj.create_function_spaces()
    elev_init=D0*(sqrt(1-A*A)/(1-A) - 1 - (x[0]*x[0]+x[1]*x[1])*((1+A)/(1-A)-1)/(L*L))
    solverObj.assign_initial_conditions(elev=elev_init)
    solverObj.iterate()

    # Error analysis
    uv, eta = solverObj.fields.solution_2d.split()

    elev_analytic = conditional(elev_init < -bathy, -bathy, elev_init)

    eta_tilde = Function(eta.function_space())
    wd_bath_displacement = solverObj.eq_sw.bathymetry_displacement_mass_term.wd_bathymetry_displacement
    eta_tilde.project(eta+wd_bath_displacement(eta))

    area = pi*475823.23**2

    e = sqrt(errornorm(elev_analytic, eta_tilde)/(area))
    print_output(e)
    return e

if __name__ == "__main__":
    run_thacker(mesh='meshes/04.msh', alpha=0.4, dt=1440.)
